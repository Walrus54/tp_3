#ifndef IDATAREADER_H
#define IDATAREADER_H

#include <QStringList>

#include "data/ChartData.h"

// Абстракция источника данных. Новый формат -> новая реализация интерфейса,
// UI её не знает и зависит только от IDataReader.
class IDataReader
{
public:
    virtual ~IDataReader() = default;

    // Расширения файлов, которые умеет читать (в нижнем регистре, без точки).
    virtual QStringList extensions() const = 0;

    // Подходит ли читатель для данного файла (по расширению).
    virtual bool canRead(const QString &filePath) const = 0;

    // Перечислить под-источники внутри файла (таблицы БД и т.п.).
    // По умолчанию формат одиночный — пустой список.
    virtual QStringList listSubSources(const QString &filePath) const
    {
        Q_UNUSED(filePath);
        return {};
    }

    // Прочитать данные. source: "путь" либо "путь|таблица" (для SQLite).
    virtual Series read(const QString &source) = 0;
};

#endif // IDATAREADER_H
