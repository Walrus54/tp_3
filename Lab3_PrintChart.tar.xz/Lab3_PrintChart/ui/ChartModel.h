#ifndef CHARTMODEL_H
#define CHARTMODEL_H

#include <QObject>
#include <QString>
#include <memory>

#include "data/ChartData.h"
#include "data/IReaderRegistry.h"

// Наблюдаемая модель (Qt Model/View). Хранит загруженные данные и параметры
// отображения (builder/style), уведомляет представление сигналами.
// Роль контроллера выполняют слоты-мутаторы + сигналы. View не знает о парсерах.
class ChartModel : public QObject
{
    Q_OBJECT
public:
    explicit ChartModel(std::shared_ptr<IReaderRegistry> registry, QObject *parent = nullptr);

    bool hasData() const;
    const Series &data() const;
    const QString &builder() const;
    const QString &style() const;

    // Под-источники файла (таблицы БД) для выбора пользователем — без мутации.
    QStringList listSubSources(const QString &filePath) const;

public slots:
    // Загрузить источник ("путь" или "путь|таблица"), эмитит dataChanged/errorOccurred.
    void setSource(const QString &source);
    // Сменить тип графика; при изменении эмитит renderOptionsChanged.
    void setBuilder(const QString &builder);
    // Сменить стиль; при изменении эмитит renderOptionsChanged.
    void setStyle(const QString &style);

signals:
    void dataChanged();           // данные перечитаны — перестроить график
    void renderOptionsChanged();  // сменился builder/style — перерисовать из тех же данных
    void errorOccurred(const QString &message);

private:
    std::shared_ptr<IReaderRegistry> m_registry;
    Series m_data;
    bool m_hasData = false;
    QString m_builder;
    QString m_style;
};

#endif // CHARTMODEL_H
