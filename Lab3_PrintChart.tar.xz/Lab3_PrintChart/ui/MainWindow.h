#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMap>
#include <QString>
#include <functional>
#include <memory>

#include "charts/IChartBuilder.h"
#include "charts/IChartStyle.h"
#include "data/IReaderRegistry.h"
#include "print/IChartPrinter.h"
#include "ui/ChartModel.h"

QT_BEGIN_NAMESPACE
class QComboBox;
class QCheckBox;
class QPushButton;
class QTableView;
class QFileSystemModel;
class QItemSelection;
namespace Ui { class MainWindow; }
namespace QtCharts { class QChartView; }
QT_END_NAMESPACE

// Именованные фабрики плагинов (выбор по имени из выпадающего списка).
using BuilderFactory = QMap<QString, std::function<std::shared_ptr<IChartBuilder>()>>;
using StyleFactory = QMap<QString, std::function<std::shared_ptr<IChartStyle>()>>;

// Главное окно — View в MVC. Все зависимости получены извне (внедрение зависимости):
// окно не создаёт ни читателей, ни билдеров, ни принтер.
class MainWindow : public QMainWindow
{
    Q_OBJECT
public:
    MainWindow(BuilderFactory builders,
               StyleFactory styles,
               std::shared_ptr<IReaderRegistry> registry,
               std::shared_ptr<IChartPrinter> printer,
               QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onFileSelectionChanged(const QItemSelection &selected, const QItemSelection &);
    void onChartTypeChanged(const QString &name);
    void onStyleToggled(bool grayscale);
    void onOpenDirClicked();
    void onPrintClicked();
    void renderChart();              // реакция на сигналы модели
    void showError(const QString &message);

private:
    void buildUi();

    Ui::MainWindow *ui;

    BuilderFactory m_builders;
    StyleFactory m_styles;
    std::shared_ptr<IReaderRegistry> m_registry;
    std::shared_ptr<IChartPrinter> m_printer;
    std::unique_ptr<ChartModel> m_model;

    QFileSystemModel *m_fsModel;
    QTableView *m_fileView;
    QComboBox *m_chartTypeBox;
    QCheckBox *m_grayCheck;
    QPushButton *m_openDirButton;
    QPushButton *m_printButton;
    QtCharts::QChartView *m_chartView;
};

#endif // MAINWINDOW_H
