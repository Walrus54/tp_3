#ifndef ICHARTSTYLE_H
#define ICHARTSTYLE_H

#include <QtGlobal>

#include "charts/IPalette.h"

QT_BEGIN_NAMESPACE
namespace QtCharts { class QChart; }
QT_END_NAMESPACE

// Стиль графика = палитра (IPalette) + общие настройки графика (тема, фон).
// Покраска отдельных серий — обязанность билдеров через палитру; стилю больше
// не нужно знать о конкретных типах series.
class IChartStyle : public IPalette
{
public:
    // Применить к графику общие настройки (тема, фон, легенда).
    virtual void apply(QtCharts::QChart *chart) const = 0;
};

#endif // ICHARTSTYLE_H
