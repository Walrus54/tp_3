#ifndef SQLITEDATAREADER_H
#define SQLITEDATAREADER_H

#include "data/IDataReader.h"

// Читатель данных из БД SQLite. Таблицы с колонками [Time, Value].
// Поддерживает несколько таблиц в одном файле: source = "путь|таблица".
class SqliteDataReader : public IDataReader
{
public:
    QStringList extensions() const override;
    bool canRead(const QString &filePath) const override;
    QStringList listSubSources(const QString &filePath) const override;
    Series read(const QString &source) override;
};

#endif // SQLITEDATAREADER_H
