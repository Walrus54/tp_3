#include "data/SqliteDataReader.h"

#include <QFileInfo>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>
#include <atomic>

namespace
{
std::atomic<int> g_connCounter{0};

// Разбор source "путь|таблица" на путь и (опционально) имя таблицы.
QPair<QString, QString> splitSource(const QString &source)
{
    const int pos = source.indexOf('|');
    if (pos < 0)
        return {source, QString()};
    return {source.left(pos), source.mid(pos + 1)};
}
} // namespace

QStringList SqliteDataReader::extensions() const
{
    return {"sqlite", "db", "sqlite3"};
}

bool SqliteDataReader::canRead(const QString &filePath) const
{
    return extensions().contains(QFileInfo(filePath).suffix().toLower());
}

QStringList SqliteDataReader::listSubSources(const QString &filePath) const
{
    QStringList tables;
    const QString connName = "sqlite_list_" + QString::number(g_connCounter++);
    {
        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", connName);
        db.setDatabaseName(filePath);
        if (db.open()) {
            tables = db.tables(QSql::Tables);
            db.close();
        }
    }
    QSqlDatabase::removeDatabase(connName);
    return tables;
}

Series SqliteDataReader::read(const QString &source)
{
    Series series;
    const auto [path, requestedTable] = splitSource(source);

    const QString connName = "sqlite_read_" + QString::number(g_connCounter++);
    {
        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", connName);
        db.setDatabaseName(path);
        if (db.open()) {
            const QStringList tables = db.tables(QSql::Tables);
            QString table;
            // Имя таблицы — недоверенный ввод: допускаем только реально существующую
            // (защита от SQL-инъекции через интерполяцию идентификатора).
            if (requestedTable.isEmpty())
                table = tables.isEmpty() ? QString() : tables.first();
            else if (tables.contains(requestedTable))
                table = requestedTable;

            if (!table.isEmpty()) {
                series.name = table;
                QSqlQuery query(db);
                query.exec(QString("SELECT Time, Value FROM [%1]").arg(table));
                while (query.next())
                    series.points.push_back(
                        {query.value(0).toString(), query.value(1).toDouble()});
            }
            db.close();
        }
    }
    QSqlDatabase::removeDatabase(connName);
    return series;
}
