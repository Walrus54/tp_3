#include "ui/MainWindow.h"
#include "ui_MainWindow.h"

#include <QCheckBox>
#include <QComboBox>
#include <QDir>
#include <QFileDialog>
#include <QFileSystemModel>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QInputDialog>
#include <QItemSelectionModel>
#include <QLabel>
#include <QMessageBox>
#include <QPushButton>
#include <QSplitter>
#include <QStatusBar>
#include <QTableView>
#include <QVBoxLayout>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>

QT_CHARTS_USE_NAMESPACE

MainWindow::MainWindow(BuilderFactory builders,
                       StyleFactory styles,
                       std::shared_ptr<IReaderRegistry> registry,
                       std::shared_ptr<IChartPrinter> printer,
                       QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_builders(std::move(builders))
    , m_styles(std::move(styles))
    , m_registry(std::move(registry))
    , m_printer(std::move(printer))
    , m_model(std::make_unique<ChartModel>(m_registry))
{
    ui->setupUi(this);
    buildUi();

    // MVC: представление реагирует только на сигналы модели.
    connect(m_model.get(), &ChartModel::dataChanged, this, &MainWindow::renderChart);
    connect(m_model.get(), &ChartModel::renderOptionsChanged, this, &MainWindow::renderChart);
    connect(m_model.get(), &ChartModel::errorOccurred, this, &MainWindow::showError);

    // Начальные параметры отображения.
    if (!m_builders.isEmpty())
        m_model->setBuilder(m_chartTypeBox->currentText());
    m_model->setStyle(m_grayCheck->isChecked() ? "gray" : "color");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::buildUi()
{
    setWindowTitle("PrintChart");
    resize(1200, 600);

    // --- Левая часть: список файлов (выбор файла с данными) ---
    m_fsModel = new QFileSystemModel(this);
    m_fsModel->setFilter(QDir::NoDotAndDotDot | QDir::Files);
    const QString startPath = QDir::homePath();
    m_fsModel->setRootPath(startPath);

    m_fileView = new QTableView(this);
    m_fileView->setModel(m_fsModel);
    m_fileView->setRootIndex(m_fsModel->index(startPath));
    m_fileView->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_fileView->setSelectionMode(QAbstractItemView::SingleSelection);
    m_fileView->horizontalHeader()->resizeSection(0, 200);
    connect(m_fileView->selectionModel(), &QItemSelectionModel::selectionChanged,
            this, &MainWindow::onFileSelectionChanged);

    // --- Верхняя панель управления ---
    m_chartTypeBox = new QComboBox(this);
    for (const QString &name : m_builders.keys())
        m_chartTypeBox->addItem(name);
    connect(m_chartTypeBox, &QComboBox::currentTextChanged, this,
            &MainWindow::onChartTypeChanged);

    m_grayCheck = new QCheckBox("Черно-белый график", this);
    connect(m_grayCheck, &QCheckBox::toggled, this, &MainWindow::onStyleToggled);

    m_openDirButton = new QPushButton("Папка с данными…", this);
    connect(m_openDirButton, &QPushButton::clicked, this, &MainWindow::onOpenDirClicked);

    m_printButton = new QPushButton("Печать графика", this);
    connect(m_printButton, &QPushButton::clicked, this, &MainWindow::onPrintClicked);

    QHBoxLayout *topBar = new QHBoxLayout();
    topBar->addWidget(m_openDirButton);
    topBar->addStretch();
    topBar->addWidget(new QLabel("Выберите тип диаграммы", this));
    topBar->addWidget(m_chartTypeBox);
    topBar->addWidget(m_grayCheck);
    topBar->addWidget(m_printButton);

    // --- Правая часть: график ---
    m_chartView = new QChartView(this);
    m_chartView->setRenderHint(QPainter::Antialiasing);
    m_chartView->setChart(new QChart());

    QSplitter *splitter = new QSplitter(this);
    splitter->addWidget(m_fileView);
    splitter->addWidget(m_chartView);
    splitter->setStretchFactor(0, 1);
    splitter->setStretchFactor(1, 3);

    QVBoxLayout *mainLayout = new QVBoxLayout();
    mainLayout->addLayout(topBar);
    mainLayout->addWidget(splitter);
    ui->centralwidget->setLayout(mainLayout);

    statusBar()->showMessage("Выберите файл БД");
}

void MainWindow::onFileSelectionChanged(const QItemSelection &selected, const QItemSelection &)
{
    const QModelIndexList indexes = selected.indexes();
    if (indexes.isEmpty())
        return;

    const QString filePath = m_fsModel->filePath(indexes.first());
    statusBar()->showMessage("Выбранный путь : " + filePath);

    // Если в файле несколько под-источников (таблиц БД) — даём выбрать.
    QString source = filePath;
    const QStringList subs = m_model->listSubSources(filePath);
    if (subs.size() > 1) {
        bool ok = false;
        const QString table = QInputDialog::getItem(
            this, "Выбор таблицы", "Таблица:", subs, 0, false, &ok);
        if (!ok)
            return;
        source = filePath + "|" + table;
    }

    m_model->setSource(source);
}

void MainWindow::onOpenDirClicked()
{
    // Выбор папки, файлы которой показываем в левой панели.
    const QString current = m_fsModel->filePath(m_fileView->rootIndex());
    const QString dir = QFileDialog::getExistingDirectory(
        this, "Выберите папку с данными", current.isEmpty() ? QDir::homePath() : current);
    if (dir.isEmpty())
        return;
    m_fsModel->setRootPath(dir);
    m_fileView->setRootIndex(m_fsModel->index(dir));
    statusBar()->showMessage("Папка : " + dir);
}

void MainWindow::onChartTypeChanged(const QString &name)
{
    m_model->setBuilder(name);
}

void MainWindow::onStyleToggled(bool grayscale)
{
    m_model->setStyle(grayscale ? "gray" : "color");
}

void MainWindow::renderChart()
{
    if (!m_model->hasData())
        return;

    auto builderFactory = m_builders.value(m_model->builder());
    auto styleFactory = m_styles.value(m_model->style());
    if (!builderFactory || !styleFactory)
        return;

    auto builder = builderFactory();
    auto style = styleFactory();

    // Билдер красит элементы палитрой стиля, затем стиль задаёт общую тему/фон.
    QChart *chart = builder->build(m_model->data(), *style);
    style->apply(chart);

    QChart *old = m_chartView->chart();
    m_chartView->setChart(chart);
    delete old;

    statusBar()->showMessage("Ряд: " + m_model->data().name + "  (точек: "
                             + QString::number(m_model->data().points.size()) + ")");
}

void MainWindow::showError(const QString &message)
{
    statusBar()->showMessage(message);
}

void MainWindow::onPrintClicked()
{
    if (!m_model->hasData()) {
        QMessageBox::information(this, "Печать", "Сначала выберите файл с данными.");
        return;
    }

    // При печати в pdf выбираем место сохранения графика.
    const QString filePath = QFileDialog::getSaveFileName(
        this, "Сохранить график в PDF", QDir::homePath() + "/chart.pdf",
        "PDF файлы (*.pdf)");
    if (filePath.isEmpty())
        return;

    const bool ok = m_printer->print(m_chartView, filePath, m_grayCheck->isChecked());
    if (ok)
        statusBar()->showMessage("График сохранён : " + filePath);
    else
        QMessageBox::warning(this, "Печать", "Не удалось сохранить PDF.");
}
