#ifndef AGGREGATOR_H
#define AGGREGATOR_H

#include <QHash>
#include <cmath>

#include "data/ChartData.h"

// Агрегация длинных рядов по префиксу метки времени (среднее в группе).
// Графики на десятки тысяч точек нечитаемы — сводим к месяцам/годам.
namespace Aggregator
{
constexpr int kThreshold = 50;   // порог, выше которого включается агрегация
constexpr int kKeyLen = 7;       // длина ключа: 7 -> "MM.YYYY"
constexpr int kDayPrefixLen = 3; // длина "DD." в формате "DD.MM.YYYY"

inline Series aggregate(const Series &src, int keyLen = kKeyLen)
{
    Series out;
    out.name = src.name;

    QHash<QString, QPair<double, int>> acc; // ключ -> (сумма, количество)
    QVector<QString> order;                 // сохраняем порядок появления ключей

    for (const ChartPoint &p : src.points) {
        const QString &raw = p.label;
        // "DD.MM.YYYY ..." -> пропускаем день; иначе берём с начала (ISO и пр.).
        const int offset =
            (raw.size() > kDayPrefixLen && raw.at(2) == '.') ? kDayPrefixLen : 0;
        const QString key = raw.mid(offset, keyLen);

        auto it = acc.find(key);
        if (it == acc.end()) {
            acc.insert(key, {p.value, 1});
            order.push_back(key);
        } else {
            it->first += p.value;
            it->second += 1;
        }
    }

    out.points.reserve(order.size());
    for (const QString &key : order) {
        const auto &pair = acc.value(key);
        const double avg = pair.first / pair.second;
        out.points.push_back({key, std::round(avg * 100.0) / 100.0});
    }
    return out;
}

// Агрегировать только если точек больше порога, иначе вернуть как есть.
inline Series aggregateIfLarge(const Series &src)
{
    return src.points.size() > kThreshold ? aggregate(src) : src;
}
} // namespace Aggregator

#endif // AGGREGATOR_H
