#ifndef JSONDATAREADER_H
#define JSONDATAREADER_H

#include "data/IDataReader.h"

// Читатель данных из JSON. Поддерживает два формата:
//  1) массив объектов: [{"date": "...", "value": ...}, ...]
//  2) объект ряда: {"name": "...", "points": [{"Time": "...", "Value": ...}, ...]}
class JsonDataReader : public IDataReader
{
public:
    QStringList extensions() const override;
    bool canRead(const QString &filePath) const override;
    Series read(const QString &source) override;
};

#endif // JSONDATAREADER_H
