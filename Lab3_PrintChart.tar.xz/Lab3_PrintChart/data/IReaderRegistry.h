#ifndef IREADERREGISTRY_H
#define IREADERREGISTRY_H

#include <QStringList>
#include <memory>

#include "data/IDataReader.h"

// Реестр читателей с диспетчеризацией по файлу/расширению.
// GUI зависит только от реестра, а не от конкретных читателей.
class IReaderRegistry
{
public:
    virtual ~IReaderRegistry() = default;

    // Читатель, подходящий для файла, либо nullptr.
    virtual std::shared_ptr<IDataReader> readerFor(const QString &filePath) const = 0;

    // Все поддерживаемые расширения (для фильтров файлового диалога).
    virtual QStringList supportedExtensions() const = 0;
};

#endif // IREADERREGISTRY_H
