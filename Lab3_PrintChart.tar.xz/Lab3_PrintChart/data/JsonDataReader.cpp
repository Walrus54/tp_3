#include "data/JsonDataReader.h"

#include <QFile>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>

namespace
{
QString pickString(const QJsonObject &obj, std::initializer_list<const char *> keys)
{
    for (const char *k : keys)
        if (obj.contains(k))
            return obj.value(k).toVariant().toString();
    return QString();
}

double pickDouble(const QJsonObject &obj, std::initializer_list<const char *> keys)
{
    for (const char *k : keys)
        if (obj.contains(k))
            return obj.value(k).toVariant().toDouble();
    return 0.0;
}

ChartPoint pointFromObject(const QJsonObject &obj)
{
    return {pickString(obj, {"date", "Time", "time", "label"}),
            pickDouble(obj, {"value", "Value"})};
}
} // namespace

QStringList JsonDataReader::extensions() const
{
    return {"json"};
}

bool JsonDataReader::canRead(const QString &filePath) const
{
    return QFileInfo(filePath).suffix().toLower() == "json";
}

Series JsonDataReader::read(const QString &source)
{
    Series series;

    QFile file(source);
    if (!file.open(QIODevice::ReadOnly))
        return series;

    const QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    file.close();

    if (doc.isArray()) {
        // Формат 1: плоский массив точек.
        series.name = QFileInfo(source).completeBaseName();
        for (const QJsonValue &v : doc.array())
            if (v.isObject())
                series.points.push_back(pointFromObject(v.toObject()));
    } else if (doc.isObject()) {
        // Формат 2: объект ряда с полями name/points.
        const QJsonObject root = doc.object();
        series.name = pickString(root, {"name"});
        if (series.name.isEmpty())
            series.name = QFileInfo(source).completeBaseName();
        for (const QJsonValue &v : root.value("points").toArray())
            if (v.isObject())
                series.points.push_back(pointFromObject(v.toObject()));
    }
    return series;
}
