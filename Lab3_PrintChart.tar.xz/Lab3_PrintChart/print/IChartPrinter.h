#ifndef ICHARTPRINTER_H
#define ICHARTPRINTER_H

#include <QString>
#include <QtCharts/QChartView>

// Абстракция печати графика. UI зависит только от интерфейса.
class IChartPrinter
{
public:
    virtual ~IChartPrinter() = default;

    // Напечатать содержимое представления графика в файл.
    // grayscale=true -> печать в оттенках серого.
    virtual bool print(QtCharts::QChartView *view,
                        const QString &filePath,
                        bool grayscale) = 0;
};

#endif // ICHARTPRINTER_H
