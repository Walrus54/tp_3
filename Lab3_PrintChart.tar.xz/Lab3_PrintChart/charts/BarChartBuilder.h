#ifndef BARCHARTBUILDER_H
#define BARCHARTBUILDER_H

#include "charts/IChartBuilder.h"

// Столбчатая диаграмма (BarChart).
class BarChartBuilder : public IChartBuilder
{
public:
    QtCharts::QChart *build(const Series &data, const IPalette &palette) const override;
};

#endif // BARCHARTBUILDER_H
