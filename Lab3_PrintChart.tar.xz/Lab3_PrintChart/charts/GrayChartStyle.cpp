#include "charts/GrayChartStyle.h"

#include <QColor>
#include <QtCharts/QChart>
#include <algorithm>

QT_CHARTS_USE_NAMESPACE

QColor GrayChartStyle::colorFor(int index, int total) const
{
    const int gray = 60 + (index * 170) / std::max(total - 1, 1); // диапазон 60..230
    return QColor(gray, gray, gray);
}

void GrayChartStyle::apply(QChart *chart) const
{
    chart->setTheme(QChart::ChartThemeLight);
    chart->setBackgroundBrush(Qt::white);
}
