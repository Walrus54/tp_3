#ifndef CHARTDATA_H
#define CHARTDATA_H

#include <QString>
#include <QVector>

// Единый формат данных для печати: пара [метка времени, значение].
// К этому типу приводятся данные из любого источника (SQLite, JSON, ...).
struct ChartPoint
{
    QString label;   // дата/время в виде строки
    double value;    // числовое значение
};

// Временной ряд: имя (таблица БД / имя ряда JSON) и набор точек.
struct Series
{
    QString name;
    QVector<ChartPoint> points;
};

#endif // CHARTDATA_H
