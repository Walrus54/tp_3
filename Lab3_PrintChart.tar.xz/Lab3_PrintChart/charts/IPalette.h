#ifndef IPALETTE_H
#define IPALETTE_H

class QColor;

// Поставляет цвета по индексу элемента — без знания о конкретных series Qt.
// Билдеры запрашивают цвет по индексу серии/среза; раскраска переезжает туда,
// где известна структура series, а стили перестают делать qobject_cast.
class IPalette
{
public:
    virtual ~IPalette() = default;

    // Цвет для элемента index из total (total нужен стилям с градиентом).
    virtual QColor colorFor(int index, int total) const = 0;
};

#endif // IPALETTE_H
